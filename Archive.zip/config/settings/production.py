from django.core.exceptions import ImproperlyConfigured

from .base import *  # noqa: F401,F403

DEBUG = False

# ---------------------------------------------------------------------------
# Required production secrets / infrastructure
# ---------------------------------------------------------------------------
if SECRET_KEY == "unsafe-dev-key-change-me":  # noqa: F405
    raise ImproperlyConfigured("SECRET_KEY must be set in production.")
if len(SECRET_KEY.encode("utf-8")) < 32:  # noqa: F405
    raise ImproperlyConfigured(
        "SECRET_KEY must be at least 32 bytes long in production because it signs JWTs."
    )

if not env("DATABASE_URL", default="").strip():  # noqa: F405
    raise ImproperlyConfigured("DATABASE_URL must be set in production.")

render_hostname = env("RENDER_EXTERNAL_HOSTNAME", default="").strip()  # noqa: F405
if render_hostname and render_hostname not in ALLOWED_HOSTS:  # noqa: F405
    ALLOWED_HOSTS.append(render_hostname)  # noqa: F405

if "*" in ALLOWED_HOSTS:  # noqa: F405
    raise ImproperlyConfigured("Wildcard ALLOWED_HOSTS is not permitted in production.")
if not ALLOWED_HOSTS:  # noqa: F405
    raise ImproperlyConfigured("ALLOWED_HOSTS must contain at least one production host.")

# FRONTEND_URL is the canonical browser origin. Add it to CORS/CSRF allowlists
# automatically when it is an HTTPS production URL; additional preview origins
# can still be supplied through the environment variables.
if FRONTEND_URL.startswith("https://"):  # noqa: F405
    if FRONTEND_URL not in CORS_ALLOWED_ORIGINS:  # noqa: F405
        CORS_ALLOWED_ORIGINS.append(FRONTEND_URL)  # noqa: F405
    if FRONTEND_URL not in CSRF_TRUSTED_ORIGINS:  # noqa: F405
        CSRF_TRUSTED_ORIGINS.append(FRONTEND_URL)  # noqa: F405

# Render terminates TLS before forwarding traffic to the container.
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
USE_X_FORWARDED_HOST = True

SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = False
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"

SECURE_SSL_REDIRECT = env.bool("SECURE_SSL_REDIRECT", default=True)  # noqa: F405
SECURE_HSTS_SECONDS = env.int("SECURE_HSTS_SECONDS", default=3600)  # noqa: F405
SECURE_HSTS_INCLUDE_SUBDOMAINS = env.bool(  # noqa: F405
    "SECURE_HSTS_INCLUDE_SUBDOMAINS", default=False
)
SECURE_HSTS_PRELOAD = env.bool("SECURE_HSTS_PRELOAD", default=False)  # noqa: F405

WHITENOISE_AUTOREFRESH = False
WHITENOISE_USE_FINDERS = False

# Production API responses are JSON-only. This prevents the DRF browsable API
# from becoming a runtime dependency on static CSS assets and reduces the
# production attack surface. Swagger/Redoc remain available through
# drf-spectacular's dedicated documentation routes.
REST_FRAMEWORK["DEFAULT_RENDERER_CLASSES"] = (  # noqa: F405
    "rest_framework.renderers.JSONRenderer",
)


# ---------------------------------------------------------------------------
# Supabase Storage
# ---------------------------------------------------------------------------
# Retained artifacts are private and production should never silently fall back
# to the container filesystem, which is ephemeral on Render.
if not SUPABASE_STORAGE_ENABLED:  # noqa: F405
    raise ImproperlyConfigured("SUPABASE_STORAGE_ENABLED must be True in production.")

_required_storage = {
    "SUPABASE_S3_ENDPOINT": SUPABASE_S3_ENDPOINT,  # noqa: F405
    "SUPABASE_S3_REGION": SUPABASE_S3_REGION,  # noqa: F405
    "SUPABASE_S3_ACCESS_KEY_ID": SUPABASE_S3_ACCESS_KEY_ID,  # noqa: F405
    "SUPABASE_S3_SECRET_ACCESS_KEY": SUPABASE_S3_SECRET_ACCESS_KEY,  # noqa: F405
    "SUPABASE_STORAGE_BUCKET": SUPABASE_STORAGE_BUCKET,  # noqa: F405
}
for _name, _value in _required_storage.items():
    if not str(_value or "").strip():
        raise ImproperlyConfigured(f"{_name} must be set in production.")

# ---------------------------------------------------------------------------
# Supabase PostgreSQL
# ---------------------------------------------------------------------------
if DATABASES["default"]["ENGINE"] != "django.db.backends.postgresql":  # noqa: F405
    raise ImproperlyConfigured("Production DATABASE_URL must point to PostgreSQL/Supabase.")
DATABASES["default"].setdefault("OPTIONS", {})  # noqa: F405
DATABASES["default"]["OPTIONS"].setdefault("sslmode", "require")  # noqa: F405
DATABASES["default"]["OPTIONS"].setdefault(  # noqa: F405
    "connect_timeout", DATABASE_CONNECT_TIMEOUT
)
DATABASES["default"]["OPTIONS"].setdefault(  # noqa: F405
    "application_name", "smart-battery-api"
)

# ---------------------------------------------------------------------------
# Transactional email on Render: Brevo API over HTTPS
# ---------------------------------------------------------------------------
# Render Free restricts common outbound SMTP ports. Brevo's transactional API
# runs over HTTPS and preserves Django's normal send_mail/EmailMessage API.
EMAIL_BACKEND = env(  # noqa: F405
    "EMAIL_BACKEND",
    default="apps.common.email_backends.BrevoApiEmailBackend",
).strip()

if ACCOUNT_EMAIL_ENABLED:  # noqa: F405
    if EMAIL_BACKEND != "apps.common.email_backends.BrevoApiEmailBackend":
        raise ImproperlyConfigured(
            "Production account email must use apps.common.email_backends.BrevoApiEmailBackend."
        )

    _required_brevo = {
        "BREVO_API_KEY": BREVO_API_KEY,  # noqa: F405
        "BREVO_SENDER_EMAIL": BREVO_SENDER_EMAIL,  # noqa: F405
    }
    for _name, _value in _required_brevo.items():
        if not str(_value or "").strip():
            raise ImproperlyConfigured(
                f"{_name} must be set when ACCOUNT_EMAIL_ENABLED=True in production."
            )

    if "@" not in BREVO_SENDER_EMAIL:  # noqa: F405
        raise ImproperlyConfigured("BREVO_SENDER_EMAIL must be a valid verified sender email address.")

    # Keep one authoritative sender identity. Do not require operators to maintain
    # a second DEFAULT_FROM_EMAIL environment value that can drift from Brevo.
    # The custom backend also enforces BREVO_SENDER_EMAIL when building the API
    # payload, so callers cannot spoof the From address.
    DEFAULT_FROM_EMAIL = (
        f"{BREVO_SENDER_NAME} <{BREVO_SENDER_EMAIL}>"  # noqa: F405
        if BREVO_SENDER_NAME  # noqa: F405
        else BREVO_SENDER_EMAIL  # noqa: F405
    )

    if not FRONTEND_URL.startswith("https://"):  # noqa: F405
        raise ImproperlyConfigured(
            "FRONTEND_URL must use HTTPS in production when account email security is enabled."
        )

