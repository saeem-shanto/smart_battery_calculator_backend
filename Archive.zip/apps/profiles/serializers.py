from rest_framework import serializers


class ProfileUploadSerializer(serializers.Serializer):
    file = serializers.FileField(
        help_text="CSV/TXT/XLS/XLSX profile file. NEM12 is supported for load-role CSV/TXT uploads."
    )
    data_role = serializers.ChoiceField(
        choices=["load", "pv", "combined"],
        help_text="Whether the file contains household load, PV generation, or both.",
    )
    value_kind = serializers.ChoiceField(
        choices=["auto", "energy_kwh_interval", "power_kw"],
        default="auto",
    )
    interval_minutes = serializers.IntegerField(
        required=False,
        min_value=1,
        max_value=1440,
        help_text="Optional interval length when it cannot be inferred from timestamps/file structure.",
    )
    consent = serializers.BooleanField()

    def validate_consent(self, value):
        if value is not True:
            raise serializers.ValidationError(
                "Consent to temporary processing is required for uploaded household data."
            )
        return value


class ProfileUploadResponseSerializer(serializers.Serializer):
    upload_token = serializers.UUIDField()
    original_name = serializers.CharField()
    detected_format = serializers.CharField()
    data_role = serializers.CharField()
    interval_minutes = serializers.IntegerField()
    value_kind = serializers.CharField()
    interval_count = serializers.IntegerField()
    warnings = serializers.ListField(child=serializers.CharField())
    expires_at = serializers.DateTimeField()


class ClientWorkbookValidationSerializer(serializers.Serializer):
    file = serializers.FileField(
        help_text="Client XLS/XLSX/CSV/TXT workbook to validate. This endpoint never stores the file or parsed values."
    )


class ClientWorkbookValidationResponseSerializer(serializers.Serializer):
    valid = serializers.BooleanField()
    original_name = serializers.CharField()
    detected_format = serializers.CharField()
    row_count = serializers.IntegerField()
    profile_is_full_year = serializers.BooleanField()
    warnings = serializers.ListField(child=serializers.CharField())
